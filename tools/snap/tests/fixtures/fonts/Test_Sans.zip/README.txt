Test Sans fixture
